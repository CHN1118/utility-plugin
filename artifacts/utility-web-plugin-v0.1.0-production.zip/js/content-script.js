(function(){console.log("Hello from the content-script")})();
//# sourceMappingURL=content-script.js.map